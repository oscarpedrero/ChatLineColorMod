﻿# ChatLineColorMod - A mod for change color of chat input same as color channel and replace string to Emoji in V Rising

## Emojis - New Featured

Now replace string to emoticons:

|STRING|STRING|EMOJI
|----------------|-------------------------------|-----------------------------|
|xE|`:grin:`|😁
|xD|`:joy:`|😂
|:)|`:smiley:`|😃
|:D|`:smile:`|😄
|;D|`:sweat_smile:`|😅
|lol|`:laughing:`|😆
|;)|`:wink:`|😉
|x)|`:blush:`|😊
|:P|`:yum:`|😋
|<3)|`:heart_eyes:`|😍
|:*|`:kissing_heart:`|😘